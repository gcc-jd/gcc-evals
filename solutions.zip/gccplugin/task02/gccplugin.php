<?php
/**
 * Plugin Name: GCC Plugin
 * Description: Displays "GCC best meat delivery" on all WooCommerce pages before the main content.
 * Version: 1.0
 * Author: Your Name
 * Author URI: https://yourwebsite.com
 * Text Domain: gccplugin
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; 
}

function gccplugin_display_message_before_content() {
    ?>
    <div style="display: flex; justify-content: space-between;">
        <div>GCC best meat delivery</div>
    </div>
    <?php 
}
add_action( 'woocommerce_before_main_content', 'gccplugin_display_message_before_content', 5 );
