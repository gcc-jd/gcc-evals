<?php
/**
 * Plugin Name: GCC Plugin
 * Description: Displays "GCC best meat delivery" on all WooCommerce pages before the main content.
 * Version: 1.0
 * Author: Your Name
 * Author URI: https://yourwebsite.com
 * Text Domain: gccplugin
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; 
}

function test_cat_api() {
    $response = wp_remote_get('https://api.thecatapi.com/v1/images/search');
    $body = wp_remote_retrieve_body($response);
    $cat_image = json_decode($body, true);
    return $cat_image;
}

function gccplugin_display_message_before_content() {
    wp_enqueue_style('gccplugincss', plugins_url( '/gccplugincss.css', __FILE__ ) );
    ?>
    <div style="text-align: center; display: flex; justify-content: space-between; background-color: #f8d7da; padding: 15px; font-size: 20px; font-weight: bold;">
        <div>GCC best meat delivery</div>
        <div style="aspect-ratio: 1; overflow: hidden; width: 400px" class="johImage">
            <img src="<?php $img = test_cat_api(); echo $img[0]['url'];?>" alt="">
        </div>
    </div>
    <?php 
}
add_action( 'woocommerce_before_main_content', 'gccplugin_display_message_before_content', 5 );
